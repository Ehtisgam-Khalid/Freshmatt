<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
    public const STATUSES = [
        'pending' => 'Pending',
        'confirmed' => 'Confirmed',
        'out_for_delivery' => 'Out for delivery',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled',
    ];

    public function loginForm()
    {
        return view('admin.login', ['enabled' => filled(config('shop.admin_password'))]);
    }

    public function login(Request $request)
    {
        $password = (string) config('shop.admin_password');

        if ($password !== '' && hash_equals($password, (string) $request->input('password'))) {
            $request->session()->regenerate();
            $request->session()->put('is_admin', true);

            return redirect('/admin');
        }

        return back()->withErrors(['password' => 'Galat password.']);
    }

    public function logout(Request $request)
    {
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/admin/login');
    }

    public function index(Request $request)
    {
        $query = Order::withCount('items')->orderByDesc('id');

        if ($request->filled('status') && isset(self::STATUSES[$request->status])) {
            $query->where('status', $request->status);
        }

        if ($request->filled('q')) {
            $q = '%'.mb_strtolower($request->q).'%';
            $query->where(function ($w) use ($q) {
                $w->whereRaw('lower(order_number) like ?', [$q])
                  ->orWhereRaw('lower(customer_name) like ?', [$q])
                  ->orWhereRaw('lower(phone) like ?', [$q]);
            });
        }

        $stats = [
            'total' => Order::count(),
            'pending' => Order::where('status', 'pending')->count(),
            'today' => Order::whereDate('created_at', now()->toDateString())->count(),
            'revenue' => (float) Order::where('status', '!=', 'cancelled')->sum('total'),
        ];

        return view('admin.orders', [
            'orders' => $query->paginate(20)->withQueryString(),
            'stats' => $stats,
            'statuses' => self::STATUSES,
        ]);
    }

    public function show(Order $order)
    {
        return view('admin.order', [
            'order' => $order->load('items'),
            'statuses' => self::STATUSES,
        ]);
    }

    public function updateStatus(Request $request, Order $order)
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(array_keys(self::STATUSES))],
        ]);

        $order->update(['status' => $data['status']]);

        return back()->with('ok', 'Status update ho gaya.');
    }
}
