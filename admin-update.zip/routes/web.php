<?php

use App\Http\Controllers\AdminController;
use App\Http\Middleware\AdminAuth;
use Illuminate\Support\Facades\Route;

// ---------- Admin panel ----------
Route::prefix('admin')->group(function () {
    Route::get('login', [AdminController::class, 'loginForm']);
    Route::post('login', [AdminController::class, 'login'])->middleware('throttle:10,1');

    Route::middleware(AdminAuth::class)->group(function () {
        Route::get('/', [AdminController::class, 'index']);
        Route::get('orders/{order}', [AdminController::class, 'show']);
        Route::post('orders/{order}/status', [AdminController::class, 'updateStatus']);
        Route::post('logout', [AdminController::class, 'logout']);
    });
});

// ---------- React single page app ----------
Route::view('/{any?}', 'app')->where('any', '^(?!api|up|admin).*$');
