<?php

return [
    'name' => 'FreshMart',
    'currency' => 'Rs.',
    'delivery_fee' => 150,
    'free_delivery_above' => 3000,
    // Admin panel ka password - Render Environment mein ADMIN_PASSWORD set karein
    'admin_password' => env('ADMIN_PASSWORD'),
];
