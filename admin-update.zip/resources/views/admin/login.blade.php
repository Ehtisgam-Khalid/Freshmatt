@extends('admin.layout')
@section('title', 'Login')
@section('content')
<div class="mx-auto mt-16 max-w-sm rounded-2xl bg-white p-6 shadow-sm">
    <h1 class="text-xl font-bold">🔐 Admin Login</h1>
    @if(! $enabled)
        <p class="mt-4 rounded-lg bg-orange-50 p-3 text-sm text-orange-700">
            Admin password set nahi hai. Render → Environment mein <b>ADMIN_PASSWORD</b> add karein.
        </p>
    @else
        <form method="POST" action="/admin/login" class="mt-4 space-y-3">
            @csrf
            <input type="password" name="password" class="input" placeholder="Password" required autofocus>
            @error('password')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
            <button class="btn btn-primary w-full">Login</button>
        </form>
    @endif
</div>
@endsection
