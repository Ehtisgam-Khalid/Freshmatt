@extends('admin.layout')
@section('title', 'Orders')
@php
    $badge = [
        'pending' => 'bg-yellow-100 text-yellow-800',
        'confirmed' => 'bg-blue-100 text-blue-800',
        'out_for_delivery' => 'bg-purple-100 text-purple-800',
        'delivered' => 'bg-green-100 text-green-800',
        'cancelled' => 'bg-red-100 text-red-800',
    ];
@endphp
@section('content')
<div class="grid grid-cols-2 gap-3 md:grid-cols-4">
    @foreach([['📦 Total orders', $stats['total']], ['🕐 Pending', $stats['pending']], ['📅 Aaj ke orders', $stats['today']], ['💰 Revenue', 'Rs. '.number_format($stats['revenue'])]] as [$label, $value])
        <div class="rounded-2xl bg-white p-4 shadow-sm">
            <p class="text-xs text-slate-500">{{ $label }}</p>
            <p class="mt-1 text-xl font-extrabold text-brand-700">{{ $value }}</p>
        </div>
    @endforeach
</div>

<form method="GET" class="mt-6 flex flex-col gap-2 sm:flex-row">
    <input name="q" value="{{ request('q') }}" class="input" placeholder="Order number, naam ya phone search karein">
    <select name="status" class="input sm:w-48">
        <option value="">Sab status</option>
        @foreach($statuses as $key => $label)
            <option value="{{ $key }}" @selected(request('status') === $key)>{{ $label }}</option>
        @endforeach
    </select>
    <button class="btn btn-primary">Filter</button>
</form>

<div class="mt-4 space-y-3">
    @forelse($orders as $o)
        <a href="/admin/orders/{{ $o->id }}" class="block rounded-2xl bg-white p-4 shadow-sm transition hover:shadow-md">
            <div class="flex flex-wrap items-center justify-between gap-2">
                <p class="font-bold">{{ $o->order_number }}</p>
                <span class="rounded-full px-3 py-1 text-xs font-semibold {{ $badge[$o->status] ?? 'bg-slate-100' }}">{{ $statuses[$o->status] ?? $o->status }}</span>
            </div>
            <div class="mt-2 flex flex-wrap items-center justify-between gap-2 text-sm text-slate-600">
                <span>👤 {{ $o->customer_name }} · 📞 {{ $o->phone }} · 📍 {{ $o->city }}</span>
                <span class="font-bold text-brand-700">Rs. {{ number_format($o->total) }}</span>
            </div>
            <p class="mt-1 text-xs text-slate-400">{{ $o->items_count }} items · {{ $o->created_at->format('d M Y, h:i A') }}</p>
        </a>
    @empty
        <p class="rounded-2xl bg-white p-10 text-center text-slate-500">Abhi koi order nahi hai.</p>
    @endforelse
</div>

<div class="mt-6">{{ $orders->links() }}</div>
@endsection
