<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>@yield('title', 'Admin') - FreshMart</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css'])
</head>
<body class="min-h-screen">
    @if(session('is_admin'))
    <header class="border-b border-brand-100 bg-white">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <a href="/admin" class="text-lg font-extrabold text-brand-700">🛒 FreshMart <span class="text-accent">Admin</span></a>
            <div class="flex items-center gap-2">
                <a href="/" target="_blank" class="btn btn-ghost">Website</a>
                <form method="POST" action="/admin/logout">@csrf<button class="btn btn-ghost">Logout</button></form>
            </div>
        </div>
    </header>
    @endif
    <main class="mx-auto max-w-6xl px-4 py-6">
        @if(session('ok'))
            <div class="mb-4 rounded-xl bg-brand-100 p-3 text-sm text-brand-900">✅ {{ session('ok') }}</div>
        @endif
        @yield('content')
    </main>
</body>
</html>
