@extends('admin.layout')
@section('title', $order->order_number)
@section('content')
<a href="/admin" class="text-sm text-brand-700">← Saare orders</a>

<div class="mt-3 grid gap-4 md:grid-cols-5">
    <section class="space-y-4 md:col-span-3">
        <div class="rounded-2xl bg-white p-5 shadow-sm">
            <h1 class="text-xl font-extrabold">{{ $order->order_number }}</h1>
            <p class="text-xs text-slate-400">{{ $order->created_at->format('d M Y, h:i A') }}</p>
            <table class="mt-4 w-full text-sm">
                <thead><tr class="border-b text-left text-slate-500"><th class="py-2">Product</th><th>Qty</th><th class="text-right">Total</th></tr></thead>
                <tbody>
                @foreach($order->items as $i)
                    <tr class="border-b border-slate-100">
                        <td class="py-2">{{ $i->product_name }}</td>
                        <td>{{ $i->quantity }} × {{ number_format($i->price) }}</td>
                        <td class="text-right">Rs. {{ number_format($i->line_total) }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <div class="mt-3 space-y-1 text-sm">
                <div class="flex justify-between"><span>Subtotal</span><span>Rs. {{ number_format($order->subtotal) }}</span></div>
                <div class="flex justify-between"><span>Delivery</span><span>{{ $order->delivery_fee > 0 ? 'Rs. '.number_format($order->delivery_fee) : 'FREE' }}</span></div>
                <div class="flex justify-between text-base font-bold"><span>Total (COD)</span><span>Rs. {{ number_format($order->total) }}</span></div>
            </div>
        </div>
    </section>

    <aside class="space-y-4 md:col-span-2">
        <div class="rounded-2xl bg-white p-5 text-sm shadow-sm">
            <h2 class="font-bold">Order status</h2>
            <form method="POST" action="/admin/orders/{{ $order->id }}/status" class="mt-3 space-y-3">
                @csrf
                <select name="status" class="input">
                    @foreach($statuses as $key => $label)
                        <option value="{{ $key }}" @selected($order->status === $key)>{{ $label }}</option>
                    @endforeach
                </select>
                <button class="btn btn-primary w-full">Update karein</button>
            </form>
        </div>
        <div class="rounded-2xl bg-white p-5 text-sm shadow-sm">
            <h2 class="font-bold">Customer</h2>
            <p class="mt-2">👤 {{ $order->customer_name }}</p>
            <p>📞 <a class="text-brand-700 underline" href="tel:{{ $order->phone }}">{{ $order->phone }}</a></p>
            @if($order->email)<p>✉️ {{ $order->email }}</p>@endif
            <p class="mt-2">📍 {{ $order->address }}, {{ $order->city }}</p>
            @if($order->notes)<p class="mt-2 rounded-lg bg-orange-50 p-2 text-orange-700">📝 {{ $order->notes }}</p>@endif
        </div>
    </aside>
</div>
@endsection
